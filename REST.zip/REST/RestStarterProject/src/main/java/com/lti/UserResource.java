package com.lti;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.lti.model.User;

@Path("users")
public class UserResource {
	
	//http://localhost:9090/RestStarterProject/rest/users
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public User getUser()
	{
		User user= new User("Makarand","Bhoir");
		return user;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addUser(User user)
	{
		System.out.println(user);
		
		return Response.status(201).build();
	}
	

}
