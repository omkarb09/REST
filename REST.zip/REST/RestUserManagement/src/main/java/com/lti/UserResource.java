package com.lti;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.lti.model.Users;
import com.lti.service.UserService;

@Path("users")
public class UserResource {

	
	UserService service = new UserService();
	
	//http://localhost:9090/RestUserManagement/rest/users
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateUser(Users user)
	{
		boolean result=service.updateUser(user);
		if(result)
		{
			return Response.status(201).build();
		}
		else
		{
			return Response.status(403).build();
		}
	}
	
	
	//http://localhost:9090/RestUserManagement/rest/users
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addUser(Users user)
	{
		boolean result=service.addUser(user);
		if(result)
		{
			return Response.status(201).build();
		}
		else
		{
			return Response.status(403).build();
		}
	}
	
	//http://localhost:9090/RestUserManagement/rest/users
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Users> getAllUsers()
	{
		List<Users> users= service.findAllUsers();
		return users;
	}
	
	//http://localhost:9090/RestUserManagement/rest/users/{user_name}
	@GET
	@Path("{user_name}")
	@Produces(MediaType.APPLICATION_JSON)
	public Users getUserByUsername(@PathParam("user_name") String username)
	{
		Users user=service.findUserByUsername(username);
		return user;
	}
	
	//http://localhost:9090/RestUserManagement/rest/users/{user_name}
	@DELETE
	@Path("{user_name}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response removeUserByUsername(@PathParam("user_name") String username)
	{
		boolean result=service.removeUser(username);
		if(result)
		{
			return Response.ok().build();
		}
		else
		{
			return Response.status(403).build();
		}
	}
}
